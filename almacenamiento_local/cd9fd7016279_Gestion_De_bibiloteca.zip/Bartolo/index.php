<?php
// ==============================================================================
// 1. CLASES (MODELO Y CONEXIÓN)
// ==============================================================================

class Database {
    private static $instance = null;

    public static function getConnection() {
        if (self::$instance === null) {
            try {
                $db_file = __DIR__ . '/bd_biblioteca.db';
                self::$instance = new PDO("sqlite:" . $db_file);
                self::$instance->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                self::$instance->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
                
                // Habilitar el soporte de Claves Foráneas en SQLite
                self::$instance->exec("PRAGMA foreign_keys = ON;");
            } catch (PDOException $e) {
                die("Error al conectar con SQLite: " . $e->getMessage());
            }
        }
        return self::$instance;
    }
}

class Categoria {
    private $db;

    public function __construct() {
        $this->db = Database::getConnection();
    }

    public function obtenerTodas() {
        $stmt = $this->db->query("SELECT * FROM Categorias ORDER BY nombre_categoria ASC");
        return $stmt->fetchAll();
    }
}

class Libro {
    private $db;

    public function __construct() {
        $this->db = Database::getConnection();
    }

    public function obtenerTodos() {
        $sql = "SELECT l.*, c.nombre_categoria 
                FROM Libros l 
                JOIN Categorias c ON l.id_categoria = c.id_categoria 
                ORDER BY l.id_libro DESC";
        return $this->db->query($sql)->fetchAll();
    }

    public function obtenerPorId($id) {
        $stmt = $this->db->prepare("SELECT * FROM Libros WHERE id_libro = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    public function existeCodigoBarra($codigo_barra, $id_excluir = 0) {
        $sql = "SELECT id_libro FROM Libros WHERE codigo_barra = ? AND id_libro != ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$codigo_barra, $id_excluir ? $id_excluir : 0]);
        return (bool) $stmt->fetch();
    }

    public function guardar($codigo_barra, $titulo, $autor, $id_categoria, $estado) {
        $sql = "INSERT INTO Libros (codigo_barra, titulo, autor, id_categoria, estado) VALUES (?, ?, ?, ?, ?)";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$codigo_barra, $titulo, $autor, $id_categoria, $estado]);
    }

    public function actualizar($id, $codigo_barra, $titulo, $autor, $id_categoria, $estado) {
        $sql = "UPDATE Libros SET codigo_barra = ?, titulo = ?, autor = ?, id_categoria = ?, estado = ? WHERE id_libro = ?";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$codigo_barra, $titulo, $autor, $id_categoria, $estado, $id]);
    }

    public function eliminar($id) {
        $stmt = $this->db->prepare("DELETE FROM Libros WHERE id_libro = ?");
        return $stmt->execute([$id]);
    }
}

// ==============================================================================
// 2. CONTROLADOR / LÓGICA DE SOLICITUDES
// ==============================================================================

$libroModel = new Libro();
$categoriaModel = new Categoria();

$mensaje = "";
$tipo_mensaje = "";
$id_libro_edit = "";
$codigo_barra = "";
$titulo = "";
$autor = "";
$id_categoria = "";
$estado = "Disponible";

// ACCIÓN: ELIMINAR LIBRO
if (isset($_GET['eliminar'])) {
    if ($libroModel->eliminar($_GET['eliminar'])) {
        header("Location: index.php?msg=eliminado");
        exit;
    }
}

// ACCIÓN: CARGAR DATOS PARA EDICIÓN
if (isset($_GET['editar'])) {
    $libro = $libroModel->obtenerPorId($_GET['editar']);
    if ($libro) {
        $id_libro_edit = $libro['id_libro'];
        $codigo_barra  = $libro['codigo_barra'];
        $titulo        = $libro['titulo'];
        $autor         = $libro['autor'];
        $id_categoria  = $libro['id_categoria'];
        $estado        = $libro['estado'];
    }
}

// ACCIÓN: REGISTRAR / ACTUALIZAR
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_libro_edit = $_POST['id_libro'] ?? '';
    $codigo_barra  = trim($_POST['codigo_barra']);
    $titulo        = trim($_POST['titulo']);
    $autor         = trim($_POST['autor']);
    $id_categoria  = $_POST['id_categoria'];
    $estado        = $_POST['estado'];

    $estados_permitidos = ['Disponible', 'Prestado', 'En Reparación'];

    // Validaciones
    if (empty($codigo_barra) || empty($titulo) || empty($autor) || empty($id_categoria) || empty($estado)) {
        $mensaje = "Complete los campos obligatorios.";
        $tipo_mensaje = "error";
    } elseif (!in_array($estado, $estados_permitidos)) {
        $mensaje = "El estado ingresado no es válido.";
        $tipo_mensaje = "error";
    } elseif ($libroModel->existeCodigoBarra($codigo_barra, $id_libro_edit)) {
        $mensaje = "El código de barras ingresado ya existe.";
        $tipo_mensaje = "warning";
    } else {
        if (!empty($id_libro_edit)) {
            $libroModel->actualizar($id_libro_edit, $codigo_barra, $titulo, $autor, $id_categoria, $estado);
            $mensaje = "Libro actualizado con éxito.";
        } else {
            $libroModel->guardar($codigo_barra, $titulo, $autor, $id_categoria, $estado);
            $mensaje = "Libro guardado con éxito.";
        }
        $tipo_mensaje = "success";
        
        // Limpiar variables de formulario tras guardar
        $id_libro_edit = $codigo_barra = $titulo = $autor = $id_categoria = "";
        $estado = "Disponible";
    }
}

// Cargar listas necesarias para la vista
$categorias = $categoriaModel->obtenerTodas();
$libros = $libroModel->obtenerTodos();
?>

<!-- ============================================================================== -->
<!-- 3. VISTA HTML                                                                 -->
<!-- ============================================================================== -->
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Biblioteca Central</title>
    <style>
        * { box-sizing: border-box; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        body { background-color: #f4f6f9; margin: 0; padding: 20px; color: #333; }
        .container { max-width: 1000px; margin: 0 auto; background: #fff; padding: 25px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        h2 { text-align: center; color: #1a252f; margin-bottom: 20px; }
        
        /* Mensajes de Alerta */
        .alert { padding: 12px; border-radius: 5px; margin-bottom: 20px; font-weight: 500; }
        .alert.success { background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .alert.error { background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        .alert.warning { background-color: #fff3cd; color: #856404; border: 1px solid #ffeeba; }
        .alert.info { background-color: #d1ecf1; color: #0c5460; border: 1px solid #bee5eb; }

        /* Formulario */
        .card { border: 1px solid #e1e4e8; border-radius: 6px; margin-bottom: 25px; overflow: hidden; }
        .card-header { background: #2c3e50; color: #fff; padding: 12px 15px; font-weight: bold; }
        .card-body { padding: 18px; }
        .form-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 15px; }
        .form-group { display: flex; flex-direction: column; }
        .form-group label { font-size: 14px; margin-bottom: 5px; font-weight: 600; color: #495057; }
        .form-group input, .form-group select { padding: 8px 12px; border: 1px solid #ced4da; border-radius: 4px; font-size: 14px; }
        .form-group input:focus, .form-group select:focus { outline: none; border-color: #3498db; }

        /* Botones */
        .btn-group { margin-top: 15px; }
        .btn { padding: 9px 16px; border: none; border-radius: 4px; cursor: pointer; font-size: 14px; font-weight: 600; text-decoration: none; display: inline-block; }
        .btn-success { background-color: #27ae60; color: white; }
        .btn-secondary { background-color: #7f8c8d; color: white; }
        .btn-primary { background-color: #2980b9; color: white; padding: 5px 10px; font-size: 12px; }
        .btn-danger { background-color: #c0392b; color: white; padding: 5px 10px; font-size: 12px; }
        .btn:hover { opacity: 0.9; }

        /* Tabla */
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { padding: 10px 12px; text-align: left; border-bottom: 1px solid #e1e4e8; font-size: 14px; }
        th { background-color: #ecf0f1; color: #2c3e50; }
        
        /* Badges de Estado */
        .badge { padding: 4px 8px; border-radius: 4px; font-size: 12px; font-weight: bold; }
        .badge-disponible { background-color: #27ae60; color: white; }
        .badge-prestado { background-color: #f39c12; color: white; }
        .badge-reparacion { background-color: #e74c3c; color: white; }
    </style>
</head>
<body>

<div class="container">
    <h2>Módulo de Gestión de Biblioteca Central "Estaba´s Fault"</h2>

    <!-- Feedback Mensajes -->
    <?php if (isset($_GET['msg']) && $_GET['msg'] === 'eliminado'): ?>
        <div class="alert info">Libro eliminado correctamente.</div>
    <?php endif; ?>

    <?php if (!empty($mensaje)): ?>
        <div class="alert <?= $tipo_mensaje ?>"><?= $mensaje ?></div>
    <?php endif; ?>

    <!-- FORMULARIO DE REGISTRO / EDICIÓN -->
    <div class="card">
        <div class="card-header">
            <?= $id_libro_edit ? 'Editar Libro' : 'Registrar Nuevo Libro' ?>
        </div>
        <div class="card-body">
            <form action="index.php" method="POST">
                <input type="hidden" name="id_libro" value="<?= $id_libro_edit ?>">
                
                <div class="form-grid">
                    <div class="form-group">
                        <label>Código de Barras *</label>
                        <input type="text" name="codigo_barra" value="<?= htmlspecialchars($codigo_barra) ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Título *</label>
                        <input type="text" name="titulo" value="<?= htmlspecialchars($titulo) ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Autor *</label>
                        <input type="text" name="autor" value="<?= htmlspecialchars($autor) ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Categoría *</label>
                        <select name="id_categoria" required>
                            <option value="">Seleccione una categoría</option>
                            <?php foreach ($categorias as $cat): ?>
                                <option value="<?= $cat['id_categoria'] ?>" <?= $id_categoria == $cat['id_categoria'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($cat['nombre_categoria']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Estado *</label>
                        <select name="estado" required>
                            <option value="Disponible" <?= $estado === 'Disponible' ? 'selected' : '' ?>>Disponible</option>
                            <option value="Prestado" <?= $estado === 'Prestado' ? 'selected' : '' ?>>Prestado</option>
                            <option value="En Reparación" <?= $estado === 'En Reparación' ? 'selected' : '' ?>>En Reparación</option>
                        </select>
                    </div>
                </div>

                <div class="btn-group">
                    <button type="submit" class="btn btn-success"><?= $id_libro_edit ? 'Actualizar Libro' : 'Guardar Libro' ?></button>
                    <?php if ($id_libro_edit): ?>
                        <a href="index.php" class="btn btn-secondary">Cancelar</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>

    <!-- TABLA DE CONSULTA -->
    <div class="card">
        <div class="card-header">Catálogo de Libros Registrados</div>
        <div class="card-body">
            <table>
                <thead>
                    <tr>
                        <th>Código</th>
                        <th>Título</th>
                        <th>Autor</th>
                        <th>Categoría</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($libros) > 0): ?>
                        <?php foreach ($libros as $row): ?>
                            <?php 
                                $badge_class = 'badge-disponible';
                                if ($row['estado'] === 'Prestado') $badge_class = 'badge-prestado';
                                if ($row['estado'] === 'En Reparación') $badge_class = 'badge-reparacion';
                            ?>
                            <tr>
                                <td><?= htmlspecialchars($row['codigo_barra']) ?></td>
                                <td><?= htmlspecialchars($row['titulo']) ?></td>
                                <td><?= htmlspecialchars($row['autor']) ?></td>
                                <td><?= htmlspecialchars($row['nombre_categoria']) ?></td>
                                <td><span class="badge <?= $badge_class ?>"><?= $row['estado'] ?></span></td>
                                <td>
                                    <a href="index.php?editar=<?= $row['id_libro'] ?>" class="btn btn-primary">Editar</a>
                                    <a href="index.php?eliminar=<?= $row['id_libro'] ?>" class="btn btn-danger" onclick="return confirm('¿Desea eliminar este registro?')">Eliminar</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" style="text-align: center; color: #7f8c8d;">No hay libros registrados.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

</body>
</html>