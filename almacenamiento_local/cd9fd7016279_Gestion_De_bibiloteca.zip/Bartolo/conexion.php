<?php
try {
    // Ruta al archivo de la base de datos SQLite
    $db_file = __DIR__ . '/bd_biblioteca.db';
    
    $pdo = new PDO("sqlite:" . $db_file);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

    // Habilitar el soporte de Claves Foráneas en SQLite
    $pdo->exec("PRAGMA foreign_keys = ON;");

} catch (PDOException $e) {
    die("Error al conectar con SQLite: " . $e->getMessage());
}
?>